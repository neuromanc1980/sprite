package cat.flx.sprite;

abstract public class Enemy extends Character {

    int x1, x2;

    Enemy(Game game) {
        super(game);

    }
}
